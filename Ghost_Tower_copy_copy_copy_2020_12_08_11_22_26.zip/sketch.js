var towerimage,tower;
var doorimage,door,doorGroup
var climberimage,climber,climberGroup
var ghost,ghostimage
var invisible,invisibleGroup
var gameState="play"
function preload(){
  ghostimage=loadImage("ghost-standing.png")
  doorGroup=new Group()
  climberGroup=new Group()
  climberimage=loadImage("climber.png")
  doorimage=loadImage("door.png")
  towerimage=loadImage("tower.png");
}
function setup(){
  createCanvas(600,600);
  invisibleGroup=new Group()
  tower=createSprite(300,300)
  tower.addImage(towerimage)
  tower.velocityY=1
  ghost=createSprite(200,200,50,50)
  ghost.scale=0.3
  ghost.addImage(ghostimage)
}
function draw(){
  background(0)
if(gameState=="play"){
 if(tower.y>400){
   tower.y=300
 }
  if(keyDown("left_arrow")){ghost.x=ghost.x-3}
  if(keyDown("right_arrow")){ghost.x=ghost.x+3}
 if(keyDown("space")){ghost.velocityY=-5}     
ghost.velocityY=ghost.velocityY+0.8
spawndoors()
if(climberGroup.isTouching(ghost)){
  ghost.velocityY=0
}
if(invisibleGroup.isTouching(ghost)||ghost.y>600){ghost.destroy()
gameState="end"}
drawSprites()
}
if(gameState=="end"){
  text("gameover",230,250)
}
}

function spawndoors(){
  if(frameCount%240===0){var door=createSprite(200,-50)
 door.addImage(doorimage) 
door.x=Math.round(random(120,400))
door.velocityY=1
door.lifetime=800
doorGroup.add(door)
var climber=createSprite(200,10)
climber.addImage(climberimage)
climber.x=door.x
climber.velocityY=1
climber.lifetime=800
climberGroup.add(climber)
ghost.depth=door.depth
ghost.depth +=1  
var invisible=createSprite(200,15)
invisible.width=climber.width
invisible.height=2
invsible.x=door.x
invisible.velocityY=1
invisible.debug=true;
invisibleGroup.add(invisible)
  }
  
}